import React from "react";

export const Footer = () => {
  return (
    <footer>
      <i class='far fa-copyright'></i>Copyright 2020
      <a href=''>All for you</a>
    </footer>
  );
};
