import React from "react";

export const Things = () => {
  return <div>Things</div>;
};
