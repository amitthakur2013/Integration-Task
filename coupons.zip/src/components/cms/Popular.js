import React from "react";

export const Popular = () => {
  return <div>Popular</div>;
};
