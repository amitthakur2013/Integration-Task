import React from "react";

export const CodeCreate = () => {
  return <div>CodeCreate</div>;
};
