import React from "react";
import CKEditor from "ckeditor4-react";

export const PromotionalCodeCreate = () => {
  return (
    <div className='item-create'>
      <h2 className='item-heading-create'>PromotionalCodeCreate </h2>
      <form action=''>
        <div className='form-element'>
          <label htmlFor=''>User</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Title</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Icon</label>
          <input type='file' />
        </div>
        <div className='form-element'>
          <label htmlFor=''> Sub Title</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Code</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Discount</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Amount</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Min Amount</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Max Amount</label>
          <input type='text' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Valid From</label>
          <input type='date' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Valid To</label>
          <input type='date' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Display From</label>
          <input type='date' />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Display To</label>
          <input type='date' />
        </div>

        <br />
        <div className='form-element'>
          <label htmlFor=''>Description</label>
          <CKEditor />
        </div>
        <div className='form-element'>
          <label htmlFor=''>Notes</label>
          <CKEditor />
        </div>
        <br />

        <div className='form-element'>
          <label htmlFor=''>Status</label>
          <select name='' id=''></select>
        </div>
        <div className='center'>
          <button className='blue-button'>Create</button>
          <button className='red-button'>Cancel</button>
        </div>
      </form>
    </div>
  );
};
