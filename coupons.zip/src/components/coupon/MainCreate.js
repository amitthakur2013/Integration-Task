import React from "react";

export const MainCreate = () => {
  return <div className='right-create'>MainCreate</div>;
};
