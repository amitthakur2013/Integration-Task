import React from "react";

export const MerchantCreate = () => {
  return <div>MerchantCreate</div>;
};
